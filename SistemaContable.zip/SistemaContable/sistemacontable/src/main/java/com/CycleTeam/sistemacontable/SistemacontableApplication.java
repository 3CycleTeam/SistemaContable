package com.CycleTeam.sistemacontable;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemacontableApplication {

	public static void main(String[] args) {
		SpringApplication.run(SistemacontableApplication.class, args);
	}

}
