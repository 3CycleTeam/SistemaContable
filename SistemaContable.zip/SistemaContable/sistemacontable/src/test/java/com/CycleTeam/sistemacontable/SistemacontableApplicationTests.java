package com.CycleTeam.sistemacontable;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemacontableApplicationTests {

	@Test
	void contextLoads() {
	}

}
